<template>
<div class="flex flex-col container mx-auto gap-6 max-w-2xl">
  <main class="flex flex-col justify-center items-center p-5">
    <router-view/>
  </main>
</div>
</template>
